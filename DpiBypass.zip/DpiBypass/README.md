# DPI Bypass (Android)

Local-VPN app that tunnels the whole phone through a SOCKS5 engine which applies
GoodbyeDPI-style evasion (TCP split, TLS record split, Host-case, QUIC block). No root needed.

Architecture: apps -> TUN (VpnService) -> hev-socks5-tunnel (tun2socks, native) -> SocksProxy.kt -> Desync.kt -> internet

## Build locally
```
git clone --recursive --depth 1 https://github.com/heiher/hev-socks5-tunnel app/src/main/jni/hev-socks5-tunnel
gradle assembleDebug        # Gradle 8.7, JDK 17, NDK 26.1.10909125
```
APK: app/build/outputs/apk/debug/app-debug.apk

Not supported (needs raw sockets/root): fake packets with low TTL, TCP disorder.
IPv6 traffic is not routed through the tunnel.
