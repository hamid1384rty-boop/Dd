package com.dpibypass.app

import android.content.Context
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

enum class Level(val tag: String) { INFO("INFO"), WARN("WARN"), ERROR("ERR "), DEBUG("DBG ") }

data class LogLine(val time: String, val level: Level, val msg: String)

object AppLog {
    private val fmt = SimpleDateFormat("HH:mm:ss", Locale.US)
    private val _lines = MutableStateFlow<List<LogLine>>(emptyList())
    val lines: StateFlow<List<LogLine>> = _lines
    private var file: File? = null

    /** Call once at process start. Shows the tail of the previous session (useful after a crash). */
    @Synchronized
    fun init(ctx: Context) {
        val f = File(ctx.filesDir, "session.log")
        file = f
        try {
            if (f.exists()) {
                val prev = f.readLines().takeLast(40)
                if (prev.isNotEmpty()) {
                    val out = mutableListOf(LogLine("", Level.WARN, "--- end of previous session (last lines) ---"))
                    prev.forEach { out.add(LogLine("", Level.DEBUG, it)) }
                    out.add(LogLine("", Level.WARN, "--- new session ---"))
                    _lines.value = out
                }
                f.delete()
            }
        } catch (_: Exception) {}
    }

    @Synchronized
    fun add(level: Level, msg: String) {
        val t = fmt.format(Date())
        _lines.value = (_lines.value + LogLine(t, level, msg)).takeLast(500)
        try { file?.appendText("$t ${level.tag} $msg\n") } catch (_: Exception) {}
    }

    fun i(m: String) = add(Level.INFO, m)
    fun w(m: String) = add(Level.WARN, m)
    fun e(m: String) = add(Level.ERROR, m)
    fun d(m: String) = add(Level.DEBUG, m)

    @Synchronized
    fun clear() { _lines.value = emptyList(); try { file?.delete() } catch (_: Exception) {} }

    fun asText(): String =
        _lines.value.joinToString("\n") { "${it.time} ${it.level.tag} ${it.msg}" }
}
