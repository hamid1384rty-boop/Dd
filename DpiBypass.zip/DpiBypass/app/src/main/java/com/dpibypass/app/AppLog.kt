package com.dpibypass.app

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

enum class Level(val tag: String) { INFO("INFO"), WARN("WARN"), ERROR("ERR "), DEBUG("DBG ") }

data class LogLine(val time: String, val level: Level, val msg: String)

object AppLog {
    private val fmt = SimpleDateFormat("HH:mm:ss", Locale.US)
    private val _lines = MutableStateFlow<List<LogLine>>(emptyList())
    val lines: StateFlow<List<LogLine>> = _lines

    @Synchronized
    fun add(level: Level, msg: String) {
        val line = LogLine(fmt.format(Date()), level, msg)
        _lines.value = (_lines.value + line).takeLast(500)
    }

    fun i(m: String) = add(Level.INFO, m)
    fun w(m: String) = add(Level.WARN, m)
    fun e(m: String) = add(Level.ERROR, m)
    fun d(m: String) = add(Level.DEBUG, m)

    @Synchronized
    fun clear() { _lines.value = emptyList() }

    fun asText(): String =
        _lines.value.joinToString("\n") { "${it.time} ${it.level.tag} ${it.msg}" }
}
