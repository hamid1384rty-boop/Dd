package com.dpibypass.app

/** What to actually write to the server for the first client packet. */
class Plan(val data: ByteArray, val splitAt: Int, val note: String)

/**
 * Stream-level DPI evasion, inspired by GoodbyeDPI / byedpi:
 *  - split the first packet (TLS ClientHello / HTTP request) into two TCP segments
 *  - fragment the ClientHello into two TLS records in the middle of the SNI
 *  - mix the case of the HTTP "Host" header
 */
object Desync {
    private fun u16(b: ByteArray, p: Int) =
        ((b[p].toInt() and 0xff) shl 8) or (b[p + 1].toInt() and 0xff)

    fun plan(b: ByteArray, n: Int, cfg: BypassConfig): Plan = when {
        isTlsHello(b, n) -> tls(b, n, cfg)
        isHttp(b, n) -> http(b, n, cfg)
        else -> Plan(b.copyOf(n), -1, "")
    }

    private fun isTlsHello(b: ByteArray, n: Int) =
        n > 43 && b[0].toInt() == 0x16 && b[1].toInt() == 0x03 && b[5].toInt() == 0x01

    private fun isHttp(b: ByteArray, n: Int): Boolean {
        if (n < 16) return false
        val s = String(b, 0, 4, Charsets.US_ASCII)
        return s in listOf("GET ", "POST", "HEAD", "PUT ", "DELE", "OPTI", "PATC", "CONN")
    }

    /** Returns (offsetOfHostName, length) or null. */
    private fun sniRange(b: ByteArray, n: Int): Pair<Int, Int>? {
        var p = 5 + 4 + 2 + 32
        if (p + 1 > n) return null
        p += 1 + (b[p].toInt() and 0xff)            // session id
        if (p + 2 > n) return null
        p += 2 + u16(b, p)                          // cipher suites
        if (p + 1 > n) return null
        p += 1 + (b[p].toInt() and 0xff)            // compression methods
        if (p + 2 > n) return null
        val extLen = u16(b, p); p += 2
        val end = minOf(n, p + extLen)
        while (p + 4 <= end) {
            val type = u16(b, p)
            val len = u16(b, p + 2)
            p += 4
            if (type == 0) {                        // server_name
                val nameLen = if (p + 5 <= n) u16(b, p + 3) else return null
                val start = p + 5
                return if (start + nameLen <= n) Pair(start, nameLen) else null
            }
            p += len
        }
        return null
    }

    private fun tls(b: ByteArray, n: Int, cfg: BypassConfig): Plan {
        val sni = sniRange(b, n)
        val host = sni?.let { String(b, it.first, it.second, Charsets.US_ASCII) } ?: "?"
        val complete = u16(b, 3) + 5 == n

        if (cfg.tlsRecord && sni != null && complete) {
            val body = n - 5
            val k = (sni.first - 5) + maxOf(1, sni.second / 2)   // cut inside the host name
            if (k in 1 until body) {
                val l2 = body - k
                val o2 = 5 + k
                val out = ByteArray(n + 5)
                out[0] = b[0]; out[1] = b[1]; out[2] = b[2]
                out[3] = (k shr 8).toByte(); out[4] = k.toByte()
                System.arraycopy(b, 5, out, 5, k)
                out[o2] = b[0]; out[o2 + 1] = b[1]; out[o2 + 2] = b[2]
                out[o2 + 3] = (l2 shr 8).toByte(); out[o2 + 4] = l2.toByte()
                System.arraycopy(b, 5 + k, out, o2 + 5, l2)
                val split = if (cfg.tcpSplit) o2 else -1
                return Plan(out, split, "TLS sni=$host tlsrec@$k" + if (split > 0) " +tcp-split" else "")
            }
        }
        val split = if (!cfg.tcpSplit) -1
        else if (cfg.splitFirstByte || sni == null) 1 else sni.first + maxOf(1, sni.second / 2)
        return Plan(b.copyOf(n), split, "TLS sni=$host tcp-split@$split")
    }

    private fun indexOf(b: ByteArray, n: Int, pat: String): Int {
        val p = pat.toByteArray(Charsets.US_ASCII)
        outer@ for (i in 0..n - p.size) {
            for (j in p.indices) if (b[i + j] != p[j]) continue@outer
            return i
        }
        return -1
    }

    private fun http(b: ByteArray, n: Int, cfg: BypassConfig): Plan {
        val data = b.copyOf(n)
        val idx = indexOf(data, n, "\r\nHost:")
        if (idx < 0) return Plan(data, -1, "HTTP (no Host header)")
        if (cfg.httpHostCase) {
            data[idx + 2] = 'h'.code.toByte(); data[idx + 3] = 'O'.code.toByte()
            data[idx + 4] = 's'.code.toByte(); data[idx + 5] = 'T'.code.toByte()
        }
        val split = if (!cfg.tcpSplit) -1 else if (cfg.splitFirstByte) 1 else idx + 4
        return Plan(data, split, "HTTP host-case=${cfg.httpHostCase} split@$split")
    }
}
