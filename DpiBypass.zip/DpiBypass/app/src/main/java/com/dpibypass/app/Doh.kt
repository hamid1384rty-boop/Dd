package com.dpibypass.app

import java.io.ByteArrayOutputStream
import java.net.InetAddress
import java.net.URL
import java.util.concurrent.ConcurrentHashMap
import javax.net.ssl.HttpsURLConnection

/**
 * DNS-over-HTTPS (RFC 8484), the equivalent of GoodbyeDPI's --dns-addr: DNS answers
 * from the ISP resolver are often forged, so all DNS goes through an encrypted channel.
 */
object Doh {
    @Volatile var enabled = true
    @Volatile var preferred = "1.1.1.1"
    private val cache = ConcurrentHashMap<String, Pair<InetAddress, Long>>()

    private fun servers(): List<String> =
        (listOf(preferred, "1.1.1.1", "8.8.8.8", "9.9.9.9")).distinct()

    private fun u16(b: ByteArray, p: Int) = ((b[p].toInt() and 0xff) shl 8) or (b[p + 1].toInt() and 0xff)

    /** Sends a raw DNS message, returns the raw DNS reply or null if every server failed. */
    fun query(msg: ByteArray): ByteArray? {
        for (s in servers()) {
            try {
                val c = URL("https://$s/dns-query").openConnection() as HttpsURLConnection
                c.requestMethod = "POST"
                c.connectTimeout = 3500
                c.readTimeout = 3500
                c.doOutput = true
                c.setRequestProperty("Content-Type", "application/dns-message")
                c.setRequestProperty("Accept", "application/dns-message")
                c.outputStream.use { it.write(msg) }
                if (c.responseCode == 200) return c.inputStream.use { it.readBytes() }
            } catch (_: Exception) {
            }
        }
        return null
    }

    private fun buildQuery(host: String): ByteArray {
        val o = ByteArrayOutputStream()
        o.write(byteArrayOf(0x12, 0x34, 0x01, 0x00, 0, 1, 0, 0, 0, 0, 0, 0))
        for (label in host.split(".")) { o.write(label.length); o.write(label.toByteArray(Charsets.US_ASCII)) }
        o.write(0)
        o.write(byteArrayOf(0, 1, 0, 1))
        return o.toByteArray()
    }

    private fun skipName(b: ByteArray, start: Int): Int {
        var i = start
        while (true) {
            val l = b[i].toInt() and 0xff
            if (l == 0) return i + 1
            if ((l and 0xC0) == 0xC0) return i + 2
            i += l + 1
        }
    }

    private fun parseA(r: ByteArray): InetAddress? {
        if (r.size < 12) return null
        val an = u16(r, 6)
        var p = skipName(r, 12) + 4
        for (k in 0 until an) {
            p = skipName(r, p)
            val type = u16(r, p)
            val rdlen = u16(r, p + 8)
            p += 10
            if (type == 1 && rdlen == 4) return InetAddress.getByAddress(r.copyOfRange(p, p + 4))
            p += rdlen
        }
        return null
    }

    private fun isIp(h: String) = h.contains(':') || Regex("""\d+\.\d+\.\d+\.\d+""").matches(h)

    fun resolve(host: String): InetAddress? {
        if (isIp(host)) return InetAddress.getByName(host)
        cache[host]?.let { if (System.currentTimeMillis() - it.second < 300_000) return it.first }
        if (enabled) {
            val ip = query(buildQuery(host))?.let { parseA(it) }
            if (ip != null) { cache[host] = Pair(ip, System.currentTimeMillis()); return ip }
        }
        return try { InetAddress.getByName(host) } catch (e: Exception) { null }
    }
}
