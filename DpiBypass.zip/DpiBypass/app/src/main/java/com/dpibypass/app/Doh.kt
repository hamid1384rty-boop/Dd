package com.dpibypass.app

import java.io.ByteArrayOutputStream
import java.io.DataInputStream
import java.net.InetAddress
import java.net.Socket
import java.net.URL
import java.util.concurrent.ConcurrentHashMap
import javax.net.ssl.HttpsURLConnection
import javax.net.ssl.SSLSocketFactory

/**
 * Encrypted DNS, the equivalent of GoodbyeDPI's --dns-addr: DNS answers from the ISP
 * resolver are often forged, so DNS goes through an encrypted channel instead. Tries
 * DNS-over-HTTPS first, then DNS-over-TLS (port 853) as a second channel, since a
 * network that blocks one doesn't always block the other, then falls back to the
 * device's own (possibly poisoned) resolver as a last resort.
 */
object Doh {
    @Volatile var enabled = true
    @Volatile var preferred = "1.1.1.1"
    private val cache = ConcurrentHashMap<String, Pair<InetAddress, Long>>()
    private val failCache = ConcurrentHashMap<String, Long>()

    private fun servers(): List<String> =
        (listOf(preferred, "1.1.1.1", "8.8.8.8", "9.9.9.9")).distinct()

    private fun u16(b: ByteArray, p: Int) = ((b[p].toInt() and 0xff) shl 8) or (b[p + 1].toInt() and 0xff)

    /** DNS-over-HTTPS (RFC 8484). Returns the raw DNS reply, or null if every server failed. */
    private fun queryDoh(msg: ByteArray): ByteArray? {
        for (s in servers()) {
            try {
                val c = URL("https://$s/dns-query").openConnection() as HttpsURLConnection
                c.requestMethod = "POST"
                c.connectTimeout = 1500
                c.readTimeout = 1500
                c.doOutput = true
                c.setRequestProperty("Content-Type", "application/dns-message")
                c.setRequestProperty("Accept", "application/dns-message")
                c.outputStream.use { it.write(msg) }
                if (c.responseCode == 200) return c.inputStream.use { it.readBytes() }
                AppLog.d("DoH $s: HTTP ${c.responseCode}")
            } catch (e: Exception) {
                AppLog.d("DoH $s: ${e.javaClass.simpleName}")
            }
        }
        return null
    }

    /** DNS-over-TLS (RFC 7858, port 853): same idea, different port/protocol, in case a
     *  network blocks the well-known DoH endpoints but not this one (or vice versa). */
    private fun queryDot(msg: ByteArray): ByteArray? {
        for (s in servers()) {
            try {
                Socket().use { raw ->
                    raw.connect(java.net.InetSocketAddress(s, 853), 1500)
                    raw.soTimeout = 1500
                    val ssl = (SSLSocketFactory.getDefault() as SSLSocketFactory)
                        .createSocket(raw, s, 853, true)
                    ssl.soTimeout = 1500
                    val o = ssl.outputStream
                    val len = msg.size
                    o.write(byteArrayOf((len shr 8).toByte(), len.toByte()))
                    o.write(msg); o.flush()
                    val i = DataInputStream(ssl.inputStream)
                    val rlen = i.readUnsignedShort()
                    val reply = ByteArray(rlen)
                    i.readFully(reply)
                    return reply
                }
            } catch (e: Exception) {
                AppLog.d("DoT $s: ${e.javaClass.simpleName}")
            }
        }
        return null
    }

    /** Sends a raw DNS message over DoH, then DoT, returns the reply or null if everything failed. */
    fun query(msg: ByteArray): ByteArray? {
        queryDoh(msg)?.let { return it }
        queryDot(msg)?.let { AppLog.i("DoT (port 853) got through where DoH didn't."); return it }
        AppLog.w("DoH and DoT both blocked; falling back to the carrier's own DNS (may be poisoned).")
        return null
    }

    private fun buildQuery(host: String): ByteArray {
        val o = ByteArrayOutputStream()
        o.write(byteArrayOf(0x12, 0x34, 0x01, 0x00, 0, 1, 0, 0, 0, 0, 0, 0))
        for (label in host.split(".")) { o.write(label.length); o.write(label.toByteArray(Charsets.US_ASCII)) }
        o.write(0)
        o.write(byteArrayOf(0, 1, 0, 1))
        return o.toByteArray()
    }

    private fun skipName(b: ByteArray, start: Int): Int {
        var i = start
        while (true) {
            val l = b[i].toInt() and 0xff
            if (l == 0) return i + 1
            if ((l and 0xC0) == 0xC0) return i + 2
            i += l + 1
        }
    }

    private fun parseA(r: ByteArray): InetAddress? {
        if (r.size < 12) return null
        val an = u16(r, 6)
        var p = skipName(r, 12) + 4
        for (k in 0 until an) {
            p = skipName(r, p)
            val type = u16(r, p)
            val rdlen = u16(r, p + 8)
            p += 10
            if (type == 1 && rdlen == 4) return InetAddress.getByAddress(r.copyOfRange(p, p + 4))
            p += rdlen
        }
        return null
    }

    private fun isIp(h: String) = h.contains(':') || Regex("""\d+\.\d+\.\d+\.\d+""").matches(h)

    /** How long a failed lookup is remembered, so a run of several methods against the
     *  same (blocked) host doesn't re-probe every DoH/DoT server again for each one. */
    private const val FAIL_TTL_MS = 120_000L

    fun resolve(host: String): InetAddress? {
        if (isIp(host)) return InetAddress.getByName(host)
        cache[host]?.let { if (System.currentTimeMillis() - it.second < 300_000) return it.first }
        failCache[host]?.let { if (System.currentTimeMillis() - it < FAIL_TTL_MS) return fallback(host) }
        if (enabled) {
            val ip = query(buildQuery(host))?.let { parseA(it) }
            if (ip != null) { cache[host] = Pair(ip, System.currentTimeMillis()); return ip }
            failCache[host] = System.currentTimeMillis()
        }
        return fallback(host)
    }

    private fun fallback(host: String): InetAddress? = try { InetAddress.getByName(host) } catch (e: Exception) { null }
}
