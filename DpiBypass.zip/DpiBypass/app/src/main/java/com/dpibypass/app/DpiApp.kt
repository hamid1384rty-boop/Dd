package com.dpibypass.app

import android.app.Application

class DpiApp : Application() {
    override fun onCreate() {
        super.onCreate()
        AppLog.init(this)
        val old = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { t, e ->
            AppLog.e("CRASH in thread ${t.name}: $e")
            e.stackTrace.take(12).forEach { AppLog.e("   at $it") }
            old?.uncaughtException(t, e)
        }
    }
}
