package com.dpibypass.app

import android.content.Intent
import android.net.VpnService
import android.os.ParcelFileDescriptor
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import java.io.File

class DpiVpnService : VpnService() {

    companion object {
        const val ACTION_START = "com.dpibypass.app.START"
        const val ACTION_STOP = "com.dpibypass.app.STOP"

        private val _running = MutableStateFlow(false)
        val running: StateFlow<Boolean> = _running

        @Volatile var proxy: SocksProxy? = null
    }

    private var tun: ParcelFileDescriptor? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) stopVpn() else startVpn()
        return START_NOT_STICKY
    }

    private fun startVpn() {
        if (_running.value) return
        try {
            val st = Prefs.settings(this)
            val method = Methods.byId(Prefs.selectedMethod(this))
            val cfg = Prefs.effective(method, st)
            AppLog.i("Connecting with method: ${method.name}  (DNS ${st.dns}, QUIC blocked: ${cfg.blockQuic})")

            val px = SocksProxy(cfg).also { it.start() }
            proxy = px
            AppLog.i("SOCKS5 proxy listening on 127.0.0.1:${px.port}")

            val builder = Builder()
                .setSession("DPI Bypass")
                .setMtu(1500)
                .addAddress("198.18.0.1", 32)
                .addRoute("0.0.0.0", 0)
                .addDnsServer(st.dns)
            builder.addDisallowedApplication(packageName)   // our own sockets bypass the tunnel

            val pfd = builder.establish()
                ?: throw IllegalStateException("VpnService.establish() returned null")
            tun = pfd

            val conf = File(filesDir, "tproxy.yml")
            conf.writeText(
                """
                misc:
                  task-stack-size: 81920
                tunnel:
                  mtu: 1500
                  ipv4: 198.18.0.1
                socks5:
                  port: ${px.port}
                  address: 127.0.0.1
                  udp: 'udp'
                """.trimIndent() + "\n"
            )
            TProxyService.TProxyStartService(conf.absolutePath, pfd.fd)

            _running.value = true
            AppLog.i("Tunnel is up. All device traffic is routed through the bypass engine.")
        } catch (t: Throwable) {
            AppLog.e("Start failed: ${t.javaClass.simpleName}: ${t.message}")
            stopVpn()
        }
    }

    private fun cleanup() {
        runCatching { TProxyService.TProxyStopService() }
        proxy?.stop(); proxy = null
        runCatching { tun?.close() }; tun = null
        if (_running.value) AppLog.i("Tunnel stopped.")
        _running.value = false
    }

    private fun stopVpn() {
        cleanup()
        stopSelf()
    }

    override fun onRevoke() { stopVpn() }
    override fun onDestroy() { cleanup(); super.onDestroy() }
}
