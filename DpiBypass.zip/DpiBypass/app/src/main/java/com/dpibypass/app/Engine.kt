package com.dpibypass.app

import android.content.Context
import kotlinx.coroutines.flow.MutableStateFlow

enum class Phase { IDLE, TESTING, CHOOSE }
enum class RowState { WAITING, TESTING, DONE }

data class MethodRow(
    val method: Method,
    val state: RowState = RowState.WAITING,
    val ok: Int = 0,
    val total: Int = 0,
    val avgMs: Long = 0
)

/** Runs the "find a working method" test and exposes its progress to the UI. */
object Engine {
    val phase = MutableStateFlow(Phase.IDLE)
    val rows = MutableStateFlow(Methods.all.map { MethodRow(it) })
    val selected = MutableStateFlow<String?>(null)
    val bestId = MutableStateFlow<String?>(null)
    @Volatile private var cancelled = false

    private fun update(idx: Int, f: (MethodRow) -> MethodRow) {
        rows.value = rows.value.mapIndexed { i, r -> if (i == idx) f(r) else r }
    }

    fun startTest(ctx: Context, onAutoPick: (String) -> Unit) {
        if (phase.value == Phase.TESTING) return
        val st = Prefs.settings(ctx)
        val saved = Prefs.selectedMethod(ctx)
        cancelled = false
        phase.value = Phase.TESTING
        rows.value = Methods.all.map { MethodRow(it) }
        selected.value = null
        bestId.value = null
        AppLog.i("Testing ${Methods.all.size} methods on: ${st.hostList.joinToString(", ")}")

        Thread {
            for ((idx, m) in Methods.all.withIndex()) {
                if (cancelled) break
                update(idx) { it.copy(state = RowState.TESTING) }
                val o = MethodTester.run(st.hostList, Prefs.effective(m, st))
                update(idx) { it.copy(state = RowState.DONE, ok = o.ok, total = o.total, avgMs = o.avgMs) }
                AppLog.i("${m.name}: ${o.ok}/${o.total}" + if (o.ok > 0) "  avg ${o.avgMs} ms" else "  failed")
            }
            if (cancelled) {
                AppLog.w("Test cancelled.")
                phase.value = Phase.IDLE
                return@Thread
            }
            val best = rows.value.filter { it.ok > 0 }
                .sortedWith(
                    compareByDescending<MethodRow> { it.ok }
                        .thenBy { it.method.id == "direct" }   // prefer a real bypass on ties
                        .thenBy { it.avgMs }
                ).firstOrNull()
            bestId.value = best?.method?.id
            selected.value = best?.method?.id ?: saved ?: Methods.all.last().id
            phase.value = Phase.CHOOSE
            if (best == null) AppLog.w("No method worked. Check your internet, test sites or DNS in Settings.")
            else AppLog.i("Best method: ${best.method.name}")
            if (best != null && st.autoPick) onAutoPick(best.method.id)
        }.start()
    }

    fun cancel() { cancelled = true }
    fun reset() { phase.value = Phase.IDLE }
}
