package com.dpibypass.app

import android.content.Intent
import android.net.VpnService
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts

class MainActivity : ComponentActivity() {

    private val vpnPermission =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
            if (r.resultCode == RESULT_OK) startVpn() else AppLog.w("VPN permission was denied.")
        }

    private fun serviceIntent(action: String) =
        Intent(this, DpiVpnService::class.java).setAction(action)

    private fun startVpn() { startService(serviceIntent(DpiVpnService.ACTION_START)) }

    private fun connect(methodId: String) {
        Prefs.setSelectedMethod(this, methodId)
        val intent = VpnService.prepare(this)
        if (intent != null) vpnPermission.launch(intent) else startVpn()
    }

    private fun disconnect() {
        startService(serviceIntent(DpiVpnService.ACTION_STOP))
        Engine.reset()
    }

    private fun startTest() {
        Engine.startTest(applicationContext) { id -> runOnUiThread { connect(id) } }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (savedInstanceState == null) AppLog.i("Ready. Tap the power button to find a working method.")
        setContent { App(onStartTest = ::startTest, onConnect = ::connect, onDisconnect = ::disconnect) }
    }
}
