package com.dpibypass.app

import java.io.BufferedReader
import java.io.DataInputStream
import java.io.InputStreamReader
import java.net.InetSocketAddress
import java.net.Socket
import javax.net.ssl.SSLSocket
import javax.net.ssl.SSLSocketFactory

/** Tries a real HTTPS request to each test site through a private SocksProxy using the given method. */
object MethodTester {
    class Outcome(val ok: Int, val total: Int, val avgMs: Long)

    fun run(hosts: List<String>, cfg: BypassConfig): Outcome {
        val proxy = SocksProxy(cfg, verbose = false).also { it.start() }
        try {
            val results = arrayOfNulls<Long>(hosts.size)
            val threads = hosts.mapIndexed { idx, h ->
                Thread { results[idx] = testHost(proxy.port, h) }.also { it.start() }
            }
            threads.forEach { it.join() }
            val okList = results.filterNotNull()
            return Outcome(okList.size, hosts.size, if (okList.isEmpty()) 0L else okList.average().toLong())
        } finally {
            proxy.stop()
        }
    }

    private fun testHost(port: Int, host: String): Long? = try {
        val t0 = System.currentTimeMillis()
        Socket().use { s ->
            s.connect(InetSocketAddress("127.0.0.1", port), 3000)
            s.soTimeout = 7000
            val o = s.getOutputStream()
            val i = DataInputStream(s.getInputStream())
            o.write(byteArrayOf(5, 1, 0)); o.flush(); i.readFully(ByteArray(2))
            val hb = host.toByteArray(Charsets.US_ASCII)
            o.write(byteArrayOf(5, 1, 0, 3, hb.size.toByte()) + hb + byteArrayOf(0x01, 0xBB.toByte()))
            o.flush()
            val rep = ByteArray(10); i.readFully(rep)
            if (rep[1].toInt() != 0) return@use null
            val ssl = (SSLSocketFactory.getDefault() as SSLSocketFactory)
                .createSocket(s, host, 443, true) as SSLSocket
            ssl.soTimeout = 7000
            ssl.startHandshake()
            ssl.outputStream.write(
                "HEAD / HTTP/1.1\r\nHost: $host\r\nUser-Agent: Mozilla/5.0\r\nConnection: close\r\n\r\n"
                    .toByteArray()
            )
            ssl.outputStream.flush()
            val line = BufferedReader(InputStreamReader(ssl.inputStream)).readLine()
            if (line != null && line.startsWith("HTTP/")) System.currentTimeMillis() - t0 else null
        }
    } catch (e: Exception) {
        null
    }
}
