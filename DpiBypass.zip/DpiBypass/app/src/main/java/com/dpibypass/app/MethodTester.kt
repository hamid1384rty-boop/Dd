package com.dpibypass.app

import java.io.BufferedReader
import java.io.DataInputStream
import java.io.InputStreamReader
import java.net.InetSocketAddress
import java.net.Socket
import javax.net.ssl.SSLSocket
import javax.net.ssl.SSLSocketFactory

/** Tries a real HTTPS request to each test site through a private SocksProxy using the given method. */
object MethodTester {
    class Outcome(val ok: Int, val total: Int, val avgMs: Long)

    fun run(hosts: List<String>, cfg: BypassConfig): Outcome {
        val proxy = SocksProxy(cfg, verbose = false).also { it.start() }
        try {
            val results = arrayOfNulls<Pair<Long?, String>>(hosts.size)
            val threads = hosts.mapIndexed { idx, h ->
                Thread { results[idx] = testHost(proxy.port, h) }.also { it.start() }
            }
            threads.forEach { it.join() }
            hosts.forEachIndexed { i, h -> AppLog.d("   $h  ${results[i]?.second ?: "?"}") }
            val okList = results.mapNotNull { it?.first }
            return Outcome(okList.size, hosts.size, if (okList.isEmpty()) 0L else okList.average().toLong())
        } finally {
            proxy.stop()
        }
    }

    /** Bare TCP connect straight to the resolved IP, no proxy, no TLS. Tells us whether
     *  the destination is reachable at all, or whether only the TLS handshake is being
     *  targeted (e.g. a DPI that fingerprints Java's non-browser-like ClientHello). */
    private fun rawTcpProbe(ip: java.net.InetAddress, port: Int): String {
        val t0 = System.currentTimeMillis()
        return try {
            java.net.Socket().use { it.connect(InetSocketAddress(ip, port), 4000) }
            "raw TCP OK in ${System.currentTimeMillis() - t0} ms"
        } catch (e: Exception) {
            "raw TCP ${e.javaClass.simpleName} after ${System.currentTimeMillis() - t0} ms"
        }
    }

    private fun testHost(port: Int, host: String): Pair<Long?, String> {
        val ip = Doh.resolve(host) ?: return Pair(null, "DNS failed")
        var note = ip.hostAddress ?: "?"
        if (ip.isSiteLocalAddress || ip.isLoopbackAddress || ip.isAnyLocalAddress) note += " (private IP: DNS poisoned?)"
        AppLog.d("   $host  ${rawTcpProbe(ip, 443)}")
        return try {
            val t0 = System.currentTimeMillis()
            val ms: Long? = Socket().use { s ->
                s.connect(InetSocketAddress("127.0.0.1", port), 3000)
                s.soTimeout = 9000
                val o = s.getOutputStream()
                val i = DataInputStream(s.getInputStream())
                o.write(byteArrayOf(5, 1, 0)); o.flush(); i.readFully(ByteArray(2))
                val hb = host.toByteArray(Charsets.US_ASCII)
                o.write(byteArrayOf(5, 1, 0, 3, hb.size.toByte()) + hb + byteArrayOf(0x01, 0xBB.toByte()))
                o.flush()
                val rep = ByteArray(10); i.readFully(rep)
                if (rep[1].toInt() != 0) return@use null
                val ssl = (SSLSocketFactory.getDefault() as SSLSocketFactory)
                    .createSocket(s, host, 443, true) as SSLSocket
                ssl.soTimeout = 9000
                ssl.startHandshake()
                ssl.outputStream.write(
                    "HEAD / HTTP/1.1\r\nHost: $host\r\nUser-Agent: Mozilla/5.0\r\nConnection: close\r\n\r\n"
                        .toByteArray()
                )
                ssl.outputStream.flush()
                val line = BufferedReader(InputStreamReader(ssl.inputStream)).readLine()
                if (line != null && line.startsWith("HTTP/")) System.currentTimeMillis() - t0 else null
            }
            if (ms != null) Pair(ms, "$note  OK $ms ms") else Pair(null, "$note  no HTTP reply")
        } catch (e: Exception) {
            Pair(null, "$note  ${e.javaClass.simpleName}")
        }
    }
}
