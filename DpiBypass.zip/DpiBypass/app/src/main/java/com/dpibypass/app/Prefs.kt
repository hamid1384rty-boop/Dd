package com.dpibypass.app

import android.content.Context

data class BypassConfig(
    val tcpSplit: Boolean = false,        // send the first packet in two TCP segments
    val fixedSplit: Int = 0,              // >0: cut after N bytes (like GoodbyeDPI -e N) instead of inside the SNI
    val tlsRecord: Boolean = false,       // split the ClientHello into two TLS records
    val httpHostCase: Boolean = true,     // "Host:" -> "hOsT:" for plain HTTP
    val blockQuic: Boolean = true         // drop UDP/443 so browsers fall back to TCP
)

data class Method(val id: String, val name: String, val desc: String, val cfg: BypassConfig)

object Methods {
    val all = listOf(
        Method("direct", "Direct (no bypass)", "Baseline, nothing is modified", BypassConfig(httpHostCase = false)),
        Method("split_sni", "TCP split at SNI", "Cuts the first packet inside the site name", BypassConfig(tcpSplit = true)),
        Method("split_1", "TCP split at 1 byte", "Sends 1 byte first, then the rest", BypassConfig(tcpSplit = true, fixedSplit = 1)),
        Method("split_2", "TCP split at 2 bytes", "Same idea as GoodbyeDPI -e 2", BypassConfig(tcpSplit = true, fixedSplit = 2)),
        Method("split_40", "TCP split at 40 bytes", "Same idea as GoodbyeDPI -e 40", BypassConfig(tcpSplit = true, fixedSplit = 40)),
        Method("tlsrec", "TLS record split", "Fragments the ClientHello into two records", BypassConfig(tlsRecord = true)),
        Method("tlsrec_split", "TLS record + TCP split", "Both techniques combined", BypassConfig(tcpSplit = true, tlsRecord = true))
    )
    fun byId(id: String?): Method = all.firstOrNull { it.id == id } ?: all.last()
}

data class Settings(
    val autoPick: Boolean = false,
    val hostCase: Boolean = true,
    val blockQuic: Boolean = true,
    val doh: Boolean = true,
    val dns: String = "1.1.1.1",
    val testHosts: String = "www.sciencedirect.com, chess.com, static.cloudflareinsights.com, " +
        "www.speedtest.net, hcaptcha.com, unpkg.com, www.instagram.com, telegram.org"
) {
    val hostList: List<String>
        get() = testHosts.split(",").map { it.trim() }.filter { it.isNotEmpty() }.take(10)
            .ifEmpty { listOf("www.youtube.com") }
}

object Prefs {
    private fun sp(c: Context) = c.getSharedPreferences("cfg", Context.MODE_PRIVATE)

    fun settings(c: Context): Settings {
        val s = sp(c); val d = Settings()
        return Settings(
            autoPick = s.getBoolean("autoPick", d.autoPick),
            hostCase = s.getBoolean("hostCase", d.hostCase),
            blockQuic = s.getBoolean("blockQuic", d.blockQuic),
            doh = s.getBoolean("doh", d.doh),
            dns = s.getString("dns", d.dns) ?: d.dns,
            testHosts = s.getString("testHosts", d.testHosts) ?: d.testHosts
        )
    }

    fun saveSettings(c: Context, st: Settings) {
        sp(c).edit()
            .putBoolean("autoPick", st.autoPick)
            .putBoolean("hostCase", st.hostCase)
            .putBoolean("blockQuic", st.blockQuic)
            .putBoolean("doh", st.doh)
            .putString("dns", st.dns)
            .putString("testHosts", st.testHosts)
            .apply()
    }

    fun selectedMethod(c: Context): String? = sp(c).getString("method", null)
    fun setSelectedMethod(c: Context, id: String) { sp(c).edit().putString("method", id).apply() }

    fun effective(m: Method, s: Settings): BypassConfig =
        m.cfg.copy(httpHostCase = m.cfg.httpHostCase && s.hostCase, blockQuic = s.blockQuic)
}
