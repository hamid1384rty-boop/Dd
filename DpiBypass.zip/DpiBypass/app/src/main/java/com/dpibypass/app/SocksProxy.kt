package com.dpibypass.app

import java.io.DataInputStream
import java.io.OutputStream
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.ServerSocket
import java.net.Socket
import java.net.SocketAddress
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicInteger
import java.util.concurrent.atomic.AtomicLong
import java.util.concurrent.atomic.AtomicReference

/**
 * Minimal local SOCKS5 server (CONNECT + UDP ASSOCIATE).
 * tun2socks feeds the phone's traffic into it; the first TCP packet of each
 * connection is rewritten by [Desync] before it leaves the device.
 * The app itself is excluded from the VPN, so sockets created here go out directly.
 */
class SocksProxy(private val cfg: BypassConfig, private val verbose: Boolean = true) {
    private val server = ServerSocket(0, 256, InetAddress.getByName("127.0.0.1"))
    private val pool = Executors.newCachedThreadPool()
    @Volatile private var running = false

    val port: Int get() = server.localPort
    val active = AtomicInteger()
    val total = AtomicInteger()
    val up = AtomicLong()
    val down = AtomicLong()

    fun start() {
        running = true
        pool.execute {
            while (running) {
                try {
                    val s = server.accept()
                    pool.execute { handle(s) }
                } catch (e: Exception) {
                    if (running) AppLog.e("accept: ${e.message}")
                }
            }
        }
    }

    fun stop() {
        running = false
        runCatching { server.close() }
        pool.shutdownNow()
    }

    private fun reply(out: OutputStream, code: Int) {
        out.write(byteArrayOf(5, code.toByte(), 0, 1, 0, 0, 0, 0, 0, 0))
        out.flush()
    }

    private fun handle(s: Socket) {
        try {
            s.tcpNoDelay = true
            val inp = DataInputStream(s.getInputStream())
            val out = s.getOutputStream()

            if (inp.readUnsignedByte() != 5) { s.close(); return }
            inp.readFully(ByteArray(inp.readUnsignedByte()))
            out.write(byteArrayOf(5, 0)); out.flush()

            inp.readUnsignedByte()                 // version
            val cmd = inp.readUnsignedByte()
            inp.readUnsignedByte()                 // reserved
            val host = when (inp.readUnsignedByte()) {
                1 -> InetAddress.getByAddress(ByteArray(4).also { inp.readFully(it) }).hostAddress!!
                3 -> String(ByteArray(inp.readUnsignedByte()).also { inp.readFully(it) })
                4 -> InetAddress.getByAddress(ByteArray(16).also { inp.readFully(it) }).hostAddress!!
                else -> { reply(out, 8); s.close(); return }
            }
            val port = inp.readUnsignedShort()

            when (cmd) {
                1 -> tcpConnect(s, out, host, port)
                3 -> udpAssociate(s, out)
                else -> { reply(out, 7); s.close() }
            }
        } catch (e: Exception) {
            runCatching { s.close() }
        }
    }

    // ---------------------------------------------------------------- TCP

    private fun tcpConnect(client: Socket, cout: OutputStream, host: String, port: Int) {
        val remote = Socket()
        try {
            remote.connect(InetSocketAddress(host, port), 8000)
        } catch (e: Exception) {
            if (verbose) AppLog.w("connect failed $host:$port (${e.javaClass.simpleName})")
            reply(cout, 5)
            runCatching { client.close() }
            return
        }
        remote.tcpNoDelay = true
        reply(cout, 0)
        total.incrementAndGet(); active.incrementAndGet()

        pool.execute {
            try { copy(remote, client, down) } catch (_: Exception) {}
            runCatching { client.close() }; runCatching { remote.close() }
        }
        try {
            copyUp(client, remote, host, port)
        } catch (_: Exception) {
        } finally {
            runCatching { client.close() }; runCatching { remote.close() }
            active.decrementAndGet()
        }
    }

    private fun copy(from: Socket, to: Socket, counter: AtomicLong) {
        val buf = ByteArray(16384)
        val i = from.getInputStream(); val o = to.getOutputStream()
        while (true) {
            val n = i.read(buf)
            if (n < 0) break
            o.write(buf, 0, n); o.flush()
            counter.addAndGet(n.toLong())
        }
    }

    private fun copyUp(client: Socket, remote: Socket, host: String, port: Int) {
        val buf = ByteArray(16384)
        val i = client.getInputStream(); val o = remote.getOutputStream()
        var first = true
        while (true) {
            val n = i.read(buf)
            if (n < 0) break
            if (first) {
                first = false
                val plan = Desync.plan(buf, n, cfg)
                if (plan.splitAt in 1 until plan.data.size) {
                    o.write(plan.data, 0, plan.splitAt); o.flush()
                    Thread.sleep(2)
                    o.write(plan.data, plan.splitAt, plan.data.size - plan.splitAt)
                } else {
                    o.write(plan.data)
                }
                o.flush()
                if (verbose && plan.note.isNotEmpty()) AppLog.i("$host:$port  ${plan.note}")
            } else {
                o.write(buf, 0, n); o.flush()
            }
            up.addAndGet(n.toLong())
        }
    }

    // ---------------------------------------------------------------- UDP

    private class UdpPkt(val addr: InetAddress, val port: Int, val dataOff: Int)

    private fun parseUdp(b: ByteArray, len: Int): UdpPkt? {
        if (len < 10 || b[2].toInt() != 0) return null     // fragmentation unsupported
        var p = 3
        val addr = when (b[p++].toInt()) {
            1 -> InetAddress.getByAddress(b.copyOfRange(p, p + 4)).also { p += 4 }
            3 -> { val l = b[p++].toInt() and 0xff; InetAddress.getByName(String(b, p, l)).also { p += l } }
            4 -> InetAddress.getByAddress(b.copyOfRange(p, p + 16)).also { p += 16 }
            else -> return null
        }
        val port = ((b[p].toInt() and 0xff) shl 8) or (b[p + 1].toInt() and 0xff)
        return UdpPkt(addr, port, p + 2)
    }

    private fun udpAssociate(ctrl: Socket, cout: OutputStream) {
        val inSock = DatagramSocket(0, InetAddress.getByName("127.0.0.1"))
        val outSock = DatagramSocket()
        val bp = inSock.localPort
        cout.write(byteArrayOf(5, 0, 0, 1, 127, 0, 0, 1, (bp shr 8).toByte(), bp.toByte()))
        cout.flush()
        val clientAddr = AtomicReference<SocketAddress?>(null)

        pool.execute {                                   // phone -> internet
            val buf = ByteArray(65535)
            val pkt = DatagramPacket(buf, buf.size)
            try {
                while (true) {
                    pkt.length = buf.size
                    inSock.receive(pkt)
                    clientAddr.set(pkt.socketAddress)
                    val p = parseUdp(buf, pkt.length) ?: continue
                    if (cfg.blockQuic && p.port == 443) continue
                    outSock.send(DatagramPacket(buf, p.dataOff, pkt.length - p.dataOff, p.addr, p.port))
                }
            } catch (_: Exception) {}
        }
        pool.execute {                                   // internet -> phone
            val buf = ByteArray(65535)
            val pkt = DatagramPacket(buf, buf.size)
            try {
                while (true) {
                    pkt.length = buf.size
                    outSock.receive(pkt)
                    val ca = clientAddr.get() ?: continue
                    val src = pkt.address.address
                    val hdr = ByteArray(4 + src.size + 2)
                    hdr[3] = if (src.size == 4) 1 else 4
                    System.arraycopy(src, 0, hdr, 4, src.size)
                    hdr[hdr.size - 2] = (pkt.port shr 8).toByte(); hdr[hdr.size - 1] = pkt.port.toByte()
                    val resp = hdr + buf.copyOfRange(pkt.offset, pkt.offset + pkt.length)
                    inSock.send(DatagramPacket(resp, resp.size, ca))
                }
            } catch (_: Exception) {}
        }
        try { while (ctrl.getInputStream().read() >= 0) { /* wait until tun2socks closes */ } } catch (_: Exception) {}
        runCatching { inSock.close() }; runCatching { outSock.close() }; runCatching { ctrl.close() }
    }
}
