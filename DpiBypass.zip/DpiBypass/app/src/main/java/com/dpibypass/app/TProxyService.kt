package com.dpibypass.app

/**
 * JNI bridge to hev-socks5-tunnel (tun2socks). The native side registers these
 * methods for class com/dpibypass/app/TProxyService (see Application.mk: PKGNAME / CLSNAME).
 */
object TProxyService {
    init { System.loadLibrary("hev-socks5-tunnel") }

    @JvmStatic external fun TProxyStartService(configPath: String, fd: Int)
    @JvmStatic external fun TProxyStopService()
    @JvmStatic external fun TProxyGetStats(): LongArray
}
