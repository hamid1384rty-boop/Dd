package com.dpibypass.app

/**
 * JNI bridge to hev-socks5-tunnel (tun2socks). The native side registers these
 * methods for class com/dpibypass/app/TProxyService (see Application.mk: PKGNAME / CLSNAME).
 * Signatures must match the library's official API exactly (all four return a value);
 * a mismatched return type here is a classic cause of a crash the moment the native
 * call actually happens (i.e. on Connect, never during method testing).
 */
object TProxyService {
    init { System.loadLibrary("hev-socks5-tunnel") }

    @JvmStatic external fun TProxyStartService(configPath: String, fd: Int): Boolean
    @JvmStatic external fun TProxyStopService(): Boolean
    @JvmStatic external fun TProxyIsRunning(): Boolean
    @JvmStatic external fun TProxyGetStats(): LongArray
}
