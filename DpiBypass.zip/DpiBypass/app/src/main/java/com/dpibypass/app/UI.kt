package com.dpibypass.app

import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay

private val Bg = Color(0xFF0E1116)
private val CardBg = Color(0xFF171B22)
private val Green = Color(0xFF2ECC71)
private val Off = Color(0xFF4A5263)
private val TextC = Color(0xFFE6EAF0)
private val Muted = Color(0xFF8B94A3)
private val Amber = Color(0xFFF5A623)
private val Red = Color(0xFFFF5C5C)

private data class Stats(val active: Int = 0, val total: Int = 0, val up: Long = 0, val down: Long = 0)

private fun fmtBytes(b: Long): String = when {
    b < 1024 -> "$b B"
    b < 1024 * 1024 -> "%.1f KB".format(b / 1024.0)
    else -> "%.1f MB".format(b / 1048576.0)
}

@Composable
fun App(onStartTest: () -> Unit, onConnect: (String) -> Unit, onDisconnect: () -> Unit) {
    var tab by rememberSaveable { mutableIntStateOf(0) }
    MaterialTheme(colorScheme = darkColorScheme(primary = Green, onPrimary = Color(0xFF04210F), surface = Bg, onSurface = TextC)) {
        Surface(color = Bg, modifier = Modifier.fillMaxSize()) {
            Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding()) {
                Box(Modifier.weight(1f).fillMaxWidth()) {
                    when (tab) {
                        0 -> ConnectScreen(onStartTest, onConnect, onDisconnect)
                        1 -> SettingsScreen()
                        else -> LogsScreen()
                    }
                }
                TabBar(tab) { tab = it }
            }
        }
    }
}

@Composable
private fun TabBar(tab: Int, onTab: (Int) -> Unit) {
    Row(Modifier.fillMaxWidth().background(CardBg)) {
        listOf("Connect", "Settings", "Logs").forEachIndexed { i, t ->
            Column(
                Modifier.weight(1f).clickable { onTab(i) }.padding(vertical = 12.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(t, color = if (tab == i) Green else Muted, fontSize = 14.sp,
                    fontWeight = if (tab == i) FontWeight.SemiBold else FontWeight.Normal)
                Spacer(Modifier.height(4.dp))
                Box(Modifier.width(24.dp).height(3.dp).clip(RoundedCornerShape(2.dp))
                    .background(if (tab == i) Green else Color.Transparent))
            }
        }
    }
}

// ------------------------------------------------------------------ Connect

@Composable
private fun ConnectScreen(onStartTest: () -> Unit, onConnect: (String) -> Unit, onDisconnect: () -> Unit) {
    val ctx = LocalContext.current
    val running by DpiVpnService.running.collectAsState()
    val phase by Engine.phase.collectAsState()
    val rows by Engine.rows.collectAsState()
    val selected by Engine.selected.collectAsState()
    val best by Engine.bestId.collectAsState()
    var stats by remember { mutableStateOf(Stats()) }

    LaunchedEffect(running) {
        if (!running) { stats = Stats(); return@LaunchedEffect }
        while (true) {
            DpiVpnService.proxy?.let { stats = Stats(it.active.get(), it.total.get(), it.up.get(), it.down.get()) }
            delay(1000)
        }
    }

    val color = when {
        running -> Green
        phase == Phase.TESTING -> Amber
        else -> Off
    }
    val showPicker = !running && phase != Phase.IDLE

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp)) {
        Text("DPI Bypass", color = TextC, fontSize = 22.sp, fontWeight = FontWeight.Bold)
        Text("Local VPN · no root required", color = Muted, fontSize = 12.sp)
        Spacer(Modifier.height(14.dp))

        Card(colors = CardDefaults.cardColors(containerColor = CardBg), shape = RoundedCornerShape(20.dp),
            modifier = Modifier.fillMaxWidth()) {
            Column(Modifier.padding(18.dp).fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
                PowerButton(color, if (showPicker) 88.dp else 124.dp) {
                    when {
                        running -> onDisconnect()
                        phase == Phase.TESTING -> Engine.cancel()
                        else -> onStartTest()
                    }
                }
                Spacer(Modifier.height(10.dp))
                Text(
                    when {
                        running -> "Connected"
                        phase == Phase.TESTING -> "Testing methods…"
                        phase == Phase.CHOOSE -> "Choose a method"
                        else -> "Disconnected"
                    },
                    color = if (running) Green else TextC, fontSize = 18.sp, fontWeight = FontWeight.SemiBold
                )
                Text(
                    when {
                        running -> "Method: " + Methods.byId(Prefs.selectedMethod(ctx)).name
                        phase == Phase.TESTING -> "Tap the button to cancel"
                        phase == Phase.CHOOSE -> "The best result is preselected"
                        else -> "Tap the button to find a working method"
                    },
                    color = Muted, fontSize = 12.sp
                )
                if (running) {
                    Spacer(Modifier.height(14.dp))
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                        Stat("Active", "${stats.active}"); Stat("Total", "${stats.total}")
                        Stat("Up", fmtBytes(stats.up)); Stat("Down", fmtBytes(stats.down))
                    }
                }
            }
        }

        if (showPicker) {
            Spacer(Modifier.height(12.dp))
            Card(colors = CardDefaults.cardColors(containerColor = CardBg), shape = RoundedCornerShape(20.dp),
                modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(vertical = 6.dp)) {
                    rows.forEach { r ->
                        val canPick = phase == Phase.CHOOSE
                        Row(
                            Modifier.fillMaxWidth().clickable(enabled = canPick) { Engine.selected.value = r.method.id }
                                .padding(horizontal = 12.dp, vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            RadioButton(selected = selected == r.method.id, onClick = null, enabled = canPick)
                            Spacer(Modifier.width(10.dp))
                            Column(Modifier.weight(1f)) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(r.method.name, color = TextC, fontSize = 14.sp, fontWeight = FontWeight.Medium)
                                    if (r.method.id == best) {
                                        Spacer(Modifier.width(6.dp))
                                        Text("BEST", color = Green, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                    }
                                }
                                Text(r.method.desc, color = Muted, fontSize = 11.sp)
                            }
                            val (txt, col) = when (r.state) {
                                RowState.WAITING -> Pair("—", Muted)
                                RowState.TESTING -> Pair("testing…", Amber)
                                RowState.DONE ->
                                    if (r.ok > 0) Pair("${r.ok}/${r.total} · ${r.avgMs} ms", Green)
                                    else Pair("0/${r.total}", Red)
                            }
                            Text(txt, color = col, fontSize = 12.sp)
                        }
                    }
                }
            }
            Spacer(Modifier.height(12.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedButton(onClick = onStartTest, enabled = phase == Phase.CHOOSE,
                    modifier = Modifier.weight(1f).height(48.dp)) { Text("Retest") }
                Button(onClick = { selected?.let(onConnect) }, enabled = phase == Phase.CHOOSE && selected != null,
                    modifier = Modifier.weight(2f).height(48.dp)) { Text("Connect") }
            }
        }
    }
}

@Composable
private fun Stat(label: String, value: String) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(value, color = TextC, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
        Text(label, color = Muted, fontSize = 11.sp)
    }
}

@Composable
private fun PowerButton(color: Color, size: Dp, onClick: () -> Unit) {
    val c by animateColorAsState(color, label = "power")
    Box(
        Modifier.size(size).clip(CircleShape).background(c.copy(alpha = 0.14f))
            .border(3.dp, c, CircleShape).clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Canvas(Modifier.size(size * 0.39f)) {
            val sw = 6.dp.toPx()
            drawArc(
                color = c, startAngle = -60f, sweepAngle = 300f, useCenter = false,
                topLeft = Offset(sw / 2, sw / 2), size = Size(this.size.width - sw, this.size.height - sw),
                style = Stroke(sw, cap = StrokeCap.Round)
            )
            drawLine(c, Offset(this.size.width / 2, 0f), Offset(this.size.width / 2, this.size.height * 0.5f),
                strokeWidth = sw, cap = StrokeCap.Round)
        }
    }
}

// ------------------------------------------------------------------ Settings

@Composable
private fun SettingsScreen() {
    val ctx = LocalContext.current
    val running by DpiVpnService.running.collectAsState()
    var st by remember { mutableStateOf(Prefs.settings(ctx)) }
    fun upd(n: Settings) { st = n; Prefs.saveSettings(ctx, n) }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Settings", color = TextC, fontSize = 22.sp, fontWeight = FontWeight.Bold)
        if (running) Text("Changes apply the next time you connect.", color = Amber, fontSize = 12.sp)

        Card(colors = CardDefaults.cardColors(containerColor = CardBg), shape = RoundedCornerShape(20.dp),
            modifier = Modifier.fillMaxWidth()) {
            Column(Modifier.padding(vertical = 4.dp)) {
                SwitchRow("Auto-connect to best method", "Skip the selection step after testing", st.autoPick) { upd(st.copy(autoPick = it)) }
                SwitchRow("Mix case of HTTP Host", "Sends “hOsT:” on plain HTTP requests", st.hostCase) { upd(st.copy(hostCase = it)) }
                SwitchRow("Block QUIC (UDP 443)", "Forces browsers onto TCP, which can be modified", st.blockQuic) { upd(st.copy(blockQuic = it)) }
            }
        }

        Card(colors = CardDefaults.cardColors(containerColor = CardBg), shape = RoundedCornerShape(20.dp),
            modifier = Modifier.fillMaxWidth()) {
            Column(Modifier.padding(14.dp)) {
                Text("DNS server", color = TextC, fontWeight = FontWeight.Medium)
                Spacer(Modifier.height(6.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("1.1.1.1", "8.8.8.8", "9.9.9.9").forEach { d ->
                        FilterChip(selected = st.dns == d, onClick = { upd(st.copy(dns = d)) }, label = { Text(d) })
                    }
                }
            }
        }

        Card(colors = CardDefaults.cardColors(containerColor = CardBg), shape = RoundedCornerShape(20.dp),
            modifier = Modifier.fillMaxWidth()) {
            Column(Modifier.padding(14.dp)) {
                OutlinedTextField(
                    value = st.testHosts, onValueChange = { upd(st.copy(testHosts = it)) },
                    label = { Text("Test sites (comma-separated)") },
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(Modifier.height(6.dp))
                Text("Each method is tested with a real HTTPS request to these sites (max 6).",
                    color = Muted, fontSize = 11.sp)
            }
        }
    }
}

@Composable
private fun SwitchRow(title: String, desc: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(title, color = TextC, fontSize = 14.sp, fontWeight = FontWeight.Medium)
            Text(desc, color = Muted, fontSize = 11.sp)
        }
        Switch(checked = checked, onCheckedChange = onChange)
    }
}

// ------------------------------------------------------------------ Logs

@Composable
private fun LogsScreen() {
    val logs by AppLog.lines.collectAsState()
    val clip = LocalClipboardManager.current
    val state = rememberLazyListState()
    LaunchedEffect(logs.size) { if (logs.isNotEmpty()) state.scrollToItem(logs.lastIndex) }

    Column(Modifier.fillMaxSize().padding(start = 16.dp, end = 8.dp, top = 12.dp, bottom = 12.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Logs", color = TextC, fontSize = 22.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
            TextButton(onClick = { clip.setText(AnnotatedString(AppLog.asText())) }) { Text("Copy", color = Green) }
            TextButton(onClick = { AppLog.clear() }) { Text("Clear", color = Muted) }
        }
        LazyColumn(state = state, modifier = Modifier.fillMaxSize().padding(end = 8.dp)) {
            items(logs) { l ->
                val c = when (l.level) {
                    Level.INFO -> Color(0xFF7FB8FF)
                    Level.WARN -> Amber
                    Level.ERROR -> Red
                    Level.DEBUG -> Muted
                }
                Text(
                    buildAnnotatedString {
                        withStyle(SpanStyle(color = Muted)) { append(l.time + " ") }
                        withStyle(SpanStyle(color = c, fontWeight = FontWeight.Bold)) { append(l.level.tag + " ") }
                        withStyle(SpanStyle(color = TextC)) { append(l.msg) }
                    },
                    fontFamily = FontFamily.Monospace, fontSize = 11.sp, lineHeight = 15.sp,
                    modifier = Modifier.padding(vertical = 1.dp)
                )
            }
        }
    }
}
