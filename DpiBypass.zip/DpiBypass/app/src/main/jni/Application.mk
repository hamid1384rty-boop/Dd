APP_ABI := arm64-v8a armeabi-v7a x86_64
APP_PLATFORM := android-24
APP_CFLAGS := -O3 -DPKGNAME=com/dpibypass/app -DCLSNAME=TProxyService
APP_LDFLAGS := -Wl,--build-id=none
