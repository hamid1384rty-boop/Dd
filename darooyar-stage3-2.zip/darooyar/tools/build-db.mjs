// ساخت drugs.json از برچسب‌های رسمی داروی FDA (openFDA) + ترجمه فارسی با DeepSeek
// اجرا:  DEEPSEEK_API_KEY=sk-... COUNT=2000 node tools/build-db.mjs   (نیاز به Node 18+)
import fs from 'fs';
const KEY = process.env.DEEPSEEK_API_KEY, COUNT = +(process.env.COUNT || 2000), PAR = 5;
if (!KEY) { console.error('DEEPSEEK_API_KEY را تنظیم کنید'); process.exit(1); }
const OUT = new URL('../www/drugs.json', import.meta.url);
const db = fs.existsSync(OUT) ? JSON.parse(fs.readFileSync(OUT, 'utf8')) : { drugs: [], diseases: {} };
const have = new Set(db.drugs.map(d => d.en.toLowerCase().split(' ')[0]));
const slug = s => s.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '');
const cut = (a, n) => (a || []).join(' ').slice(0, n);

async function labels(skip) {
  const q = 'openfda.route:%22INTRAVENOUS%22+OR+openfda.route:%22INTRAMUSCULAR%22+OR+openfda.route:%22SUBCUTANEOUS%22';
  const r = await fetch(`https://api.fda.gov/drug/label.json?search=${q}&limit=100&skip=${skip}`);
  if (!r.ok) return [];
  return (await r.json()).results || [];
}

async function ask(l) {
  const o = l.openfda, name = o.generic_name[0];
  const src = `Generic: ${name}\nBrands: ${(o.brand_name || []).slice(0, 3).join(', ')}\nClass: ${(o.pharm_class_epc || []).join(', ')}\nRoutes: ${(o.route || []).join(', ')}\nINDICATIONS: ${cut(l.indications_and_usage, 1500)}\nMECHANISM: ${cut(l.mechanism_of_action, 800)}\nDOSAGE AND ADMINISTRATION: ${cut(l.dosage_and_administration, 3000)}`;
  const sys = 'You write a Persian (Farsi) drug reference entry using ONLY the label text given. Never invent facts; if something is not in the text, leave it out (empty string or empty list). Return JSON only: {"fa":"Persian drug name","cls":"Persian drug class","fn":"how it works / what it does, Persian, 1-2 sentences","ind":["Persian disease names"],"forms":"dosage forms in Persian","routes":[{"n":"IV|IM|SC|PO...","fa":"Persian route name","how":["step-by-step Persian instructions on how this route is administered: dilution, site, speed"]}],"dz":{"each disease name in ind":"1-2 Persian sentences explaining what the disease is and its main symptoms"}}';
  const r = await fetch('https://api.deepseek.com/chat/completions', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', Authorization: 'Bearer ' + KEY },
    body: JSON.stringify({ model: 'deepseek-chat', response_format: { type: 'json_object' }, temperature: 0.1,
      messages: [{ role: 'system', content: sys }, { role: 'user', content: src }] })
  });
  const j = await r.json();
  const x = JSON.parse(j.choices[0].message.content);
  return { id: slug(name), fa: x.fa || name, en: name.replace(/\b\w/g, c => c.toUpperCase()), cls: x.cls || '', fn: x.fn || '',
    ind: x.ind || [], forms: x.forms || '', sim: [], routes: x.routes || [], _class: (o.pharm_class_epc || [])[0] || '', _dz: x.dz || {} };
}

const added = [];
for (let skip = 0; skip <= 25000 && added.length < COUNT; skip += 100) {
  const batch = [];
  for (const l of await labels(skip)) {
    const n = l.openfda?.generic_name?.[0]; if (!n) continue;
    const k = n.toLowerCase().split(' ')[0];
    if (have.has(k)) continue; have.add(k); batch.push(l);
  }
  for (let i = 0; i < batch.length && added.length < COUNT; i += PAR) {
    const res = await Promise.allSettled(batch.slice(i, i + PAR).map(ask));
    for (const r of res) if (r.status === 'fulfilled') { added.push(r.value); Object.assign(db.diseases, r.value._dz); }
    else console.error('خطا:', r.reason?.message);
    console.log(added.length, '/', COUNT);
  }
  // ذخیره تدریجی تا با قطع شدن اجرا چیزی از دست نرود
  save();
}
function save() {
  const all = [...db.drugs.filter(d => !d._dz), ...added];
  const byClass = {};
  for (const d of all) if (d._class) (byClass[d._class] ||= []).push(d.en);
  for (const d of all) if (d._class) d.sim = byClass[d._class].filter(e => e !== d.en).slice(0, 4);
  const clean = all.map(({ _class, _dz, ...d }) => d);
  fs.writeFileSync(OUT, JSON.stringify({ drugs: clean, diseases: db.diseases }, null, 1));
}
save();
console.log('تمام شد. حتماً خروجی را داروساز یا پزشک بررسی کند.');
